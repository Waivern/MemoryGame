
const getImage = async (url) => {
  return await fetch(url).then(res => res.url)

}
async function GenereerAfbeelding(url) {

var randomplaatjes = [];
var vorigeResult = "";
  for (let i = 0; i < aantalKaarten / 2; i++) {
     try {

    
        const result = await getImage(url);
    
        if (vorigeResult != result) {
          var imageUrl = '<img src="' + result + '" alt="Memory spel afbeelding">'
          randomplaatjes.push(imageUrl);
          randomplaatjes.push(imageUrl);
      
        } else { i--; } 
    } catch(err) {
     
      console.error(`Error -> ${err}`);
      const errorMessage = 'De afbeelding kan niet opgehaald worden.';
      console.log(errorMessage);

      
    }
  }
   var array = Shuffle(randomplaatjes);
   return array;
  }

  // Functie om de willekeurige afbeeldingen toe te voegen aan de achterkant van de kaarten
  async function Voegplaatjetoe(url) {
    var randomplaatjes = await GenereerAfbeelding(url);
    console.log(randomplaatjes);

    kaartenAchterkant.forEach((kaartAchterkant, index) => {

    console.log(randomplaatjes[index]);
      kaartAchterkant.innerHTML = randomplaatjes[index];
    
      
    });
  }

function Genereerletter() {

  var alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
  const randomLetters = [];

  
  for (let i = 0; i < aantalKaarten / 2; i++) {
      var randomIndex = Math.floor(Math.random() * alphabet.length);
      //console.log(randomIndex);
      var randomLetter = alphabet[randomIndex];
      randomLetters.push(randomLetter);
      randomLetters.push(randomLetter);
      // Creëer een nieuw alphabet zonder de gebruikte letter
      alphabet = alphabet.substring(0, randomIndex) + alphabet.substring(randomIndex + 1);
  }
  var array = Shuffle(randomLetters);
  console.log(array);
  return array;
}


  // Functie om de willekeurige letters toe te voegen aan de kaarten
  function Voeglettertoe() {
    const randomLetters = Genereerletter();
    console.log(randomLetters);

    kaartenAchterkant.forEach((kaartAchterkant, index) => {
      kaartAchterkant.innerHTML = randomLetters[index];
    
      
    });
  }

  function StartColorPickers() {
  
    var colorPickerGesloten = document.querySelector("#Geslotenkleur");
    var colorPickerOpen     = document.querySelector("#Openkleur");
    var colorPickerGevonden = document.querySelector("#Gevondenkleur");
    
    colorPickerGesloten.value = "#6F6D76"; /* Kleur voor nog gesloten kaarten */
    colorPickerOpen.value = "#424D94"; /* Kleur voor geopende kaarten */
    colorPickerGevonden.value = "#31AA31"; /* Kleur voor gevonden kaarten */
  
    
    colorPickerGesloten.addEventListener("input", updateKleurGesloten, false);
    colorPickerGesloten.select();
    colorPickerOpen.addEventListener("input", updateKleurOpen, false);
    colorPickerOpen.select();
    colorPickerGevonden.addEventListener("input", updateKleurGevonden, false);
    colorPickerGevonden.select();
  }
  
  function updateKleurGesloten(event) {
    var r = document.querySelector(':root');
    r.style.setProperty('--grijs', event.target.value);
  }
  
  function updateKleurOpen(event) {
    var r = document.querySelector(':root');
    r.style.setProperty('--blauw', event.target.value);
  }
  function updateKleurGevonden(event) {
    var r = document.querySelector(':root');
    r.style.setProperty('--groen', event.target.value);
  }

  function Maakklikactie(){ kaarten.forEach(kaart => kaart.addEventListener('click', flipKaart)); }


// initieel alle kaarten 1 keer omdraaien en weer terugdraaien, mooie animatie
function unflip() { 
  kaarten.forEach(function(kaart){ 
    kaart.classList.remove('flip');
  })
}

// initieel alle kaarten 1 keer omdraaien en weer terugdraaien, mooie animatie
function unflipKaartAnimatie(Kaart) { 

    Kaart.classList.remove('flip');
}

function flipKaartAnimatie(Kaart) { 
  console.log("Hallo" + Kaart);
  Kaart.classList.add('flip');
}


//hulpfunctie shuffle de string array
function Shuffle(array) {
  
  for (let i = array.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    const temp = array[i];
    array[i] = array[j];
    array[j] = temp;
  }
  return array;
}