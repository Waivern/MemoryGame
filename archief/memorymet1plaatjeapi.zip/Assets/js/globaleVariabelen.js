/* Door Marcel Bos ITC deeltijd leerjaar 3

globale variabelen*/
// kaarten
const kaarten = document.querySelectorAll('.Kaart');
const kaartenAchterkant = document.querySelectorAll('.Kaart #achterkant');
const kaartenVoorkant = document.querySelectorAll('.Kaart #voorkant');
// later nog iets doen op basis van dit nummer met de grootte van het speelbord??
const aantalKaarten = 36; 

//gevonden kaarten opslaan in lijst voor latere checks
var paren = [];
var vorigeLetter = '';
var leegmaken = 0; 

//Colorpickers
let colorPicker;

//Afbeeldingen api's
const willekeurigUrl = 'https://picsum.photos/80';