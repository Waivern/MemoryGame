/* Door Marcel Bos ITC deeltijd leerjaar 3

globale variabelen*/
// kaarten
const kaarten = document.querySelectorAll('.Kaart');
const kaartenAchterkant = document.querySelectorAll('.Kaart #achterkant');
const kaartenVoorkant = document.querySelectorAll('.Kaart #voorkant');
// later nog iets doen op basis van dit nummer met de grootte van het speelbord??
const aantalKaarten = 36; 



//gevonden kaarten opslaan in lijst voor latere checks
var paren = [];
var vorigeLetter = '';
var leegmaken = 0; 


//Colorpickers
let colorPicker;





function StartColorPickers() {
  
  var colorPickerGesloten = document.querySelector("#Geslotenkleur");
  var colorPickerOpen     = document.querySelector("#Openkleur");
  var colorPickerGevonden = document.querySelector("#Gevondenkleur");
  
  colorPickerGesloten.value = "#6F6D76"; /* Kleur voor nog gesloten kaarten */
  colorPickerOpen.value = "#424D94"; /* Kleur voor geopende kaarten */
  colorPickerGevonden.value = "#31AA31"; /* Kleur voor gevonden kaarten */

  
  colorPickerGesloten.addEventListener("input", updateKleurGesloten, false);
  colorPickerGesloten.select();
  colorPickerOpen.addEventListener("input", updateKleurOpen, false);
  colorPickerOpen.select();
  colorPickerGevonden.addEventListener("input", updateKleurGevonden, false);
  colorPickerGevonden.select();
}

function updateKleurGesloten(event) {
  var r = document.querySelector(':root');
  r.style.setProperty('--grijs', event.target.value);
}

function updateKleurOpen(event) {
  var r = document.querySelector(':root');
  r.style.setProperty('--blauw', event.target.value);
}
function updateKleurGevonden(event) {
  var r = document.querySelector(':root');
  r.style.setProperty('--groen', event.target.value);
}





function ControleSpeelbordvol() {
  var count = 0;
  for(var i=0;i<kaarten.length;i++){

    if(kaarten[i].classList.contains('gevonden')){
      count++;
      
    }
    if(count == aantalKaarten) {
      //Felicitaties!! Met ballonnen en draaien van alle kaarten 3 keer diagonaal :D

      console.log("Gefeliciteerd!! " +count + " omgedraaid!");
      

      kaarten.forEach(function(kaart){
        var random = Math.floor(Math.random() * 3);
        if (random == 0) {
        kaart.classList.add('gewonnen');
        }
        if (random == 1) {
          kaart.classList.add('gewonnenlinks');
          }
          if (random == 2) {
            kaart.classList.add('gewonnenrechts');
            }
            document.getElementById('gewonnentekst').classList.add('gewonnentekstanimatie');
        
            document.getElementById('gewonnentekst').style.display = "block";
            
        
        });
        

      return true;
    }
    
  }
  
}


function Maakklikactie(){ kaarten.forEach(kaart => kaart.addEventListener('click', flipKaart)); }


// initieel alle kaarten 1 keer omdraaien en weer terugdraaien, mooie animatie
function unflip() { 
  kaarten.forEach(function(kaart){ 
    kaart.classList.remove('flip');
  })
}

// initieel alle kaarten 1 keer omdraaien en weer terugdraaien, mooie animatie
function unflipKaartAnimatie(Kaart) { 

    Kaart.classList.remove('flip');
}

function flipKaartAnimatie(Kaart) { 
  console.log("Hallo" + Kaart);
  Kaart.classList.add('flip');
}


//hulpfunctie shuffle de string array
function Shuffle(array) {
  
  for (let i = array.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    const temp = array[i];
    array[i] = array[j];
    array[j] = temp;
  }
  return array;
}

// Als het scherm opent alle letters 1 keer openen en sluiten.
window.onload = function(){
// allereerst een mooie begin animatie
// allereerst een mooie begin animatie
kaarten.forEach(function(kaart){

  kaart.classList.add('flip');
  
  })
  setTimeout(unflip,500);




StartColorPickers();
}



//de functie om een kaart te openen en controles te doen.
function flipKaart() {

  achterkant = this.querySelector('#achterkant');
  voorkant = this.querySelector('#voorkant');

  if (this.classList.contains('open') || (this.classList.contains('gevonden'))) {
    console.log("Kaart is al geopend of gevonden, ik doe niks");
  }
  else {
    //als leegmaken op 1 staat dan de twee (alle kaarten) weer terugdraaien.
    if (leegmaken == 1) {
      for(var i=0;i<kaarten.length;i++){
        
        if(kaarten[i].classList.contains('open')){
          
          kaartenAchterkant[i].style.display = 'none';
          kaarten[i].classList.remove('open');
          kaarten[i].classList.add('gesloten');
          kaartenVoorkant[i].style.display = 'block';
          
        }
      }
      leegmaken = 0; // Weer naar 0 zetten, anders voert hij nogmaals de if uit bij het draaien.
    }
    achterkant.style.display = 'block';
    this.classList.add('flip');
    this.classList.remove('gesloten');
    this.classList.add('open');
    setTimeout(unflip,500);
    voorkant.style.display = 'none';
    
    const huidigeLetter = achterkant.innerHTML;

    if (huidigeLetter === vorigeLetter) {
      console.log('yes ' + huidigeLetter);
      this.classList.remove('open');
      this.classList.add('gevonden');
      //andere opzoeken die zelfde letter heeft en die dan op gevonden zetten.
        for(var i=0;i<kaarten.length;i++){

          if(kaartenAchterkant[i].innerHTML == huidigeLetter){
            
            kaarten[i].classList.remove('open');
            kaarten[i].classList.add('gevonden');
            kaartenAchterkant[i].style.display = 'block';
          
          }
          
      }
      //nu even controleren of het speelbord al vol is en anders weer verder
      ControleSpeelbordvol();
      
    }
    else {
      //als er twee blauw zijn deze weer sluiten met leegmaken bool na klikken op nieuwe kaart
      var count = 0;
      //console.log("hallo ik ben erdd");
      for(var i=0;i<kaarten.length;i++){

        if(kaarten[i].classList.contains('open')){
          count++;
          //console.log("hallo ik ben er" +count);
        }
        if(count == 2) {
          leegmaken = 1;
          break;
        }
        
      }


    }
    vorigeLetter = huidigeLetter;
    paren.push(huidigeLetter);

  }
}
function GenereerAfbeelding() {
 // https://picsum.photos/id/1/200/300
  var alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
  const randomLetters = [];

  
  for (let i = 0; i < aantalKaarten / 2; i++) {
      var randomIndex = Math.floor(Math.random() * alphabet.length);
      //console.log(randomIndex);
      var randomLetter = alphabet[randomIndex];
      randomLetters.push(randomLetter);
      randomLetters.push(randomLetter);
      // Creëer een nieuw alphabet zonder de gebruikte letter
      alphabet = alphabet.substring(0, randomIndex) + alphabet.substring(randomIndex + 1);
  }
  var array = Shuffle(randomLetters);
  console.log(array);
  return array;
}

  // Functie om de willekeurige letters toe te voegen aan de kaarten
  function Voegplaatjetoe() {
    const randomLetters = GenereerAfbeelding();
    console.log(randomLetters);

    kaartenAchterkant.forEach((kaartAchterkant, index) => {
      kaartAchterkant.innerHTML = randomLetters[index];
    
      
    });
  }










function Genereerletter() {

  var alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
  const randomLetters = [];

  
  for (let i = 0; i < aantalKaarten / 2; i++) {
      var randomIndex = Math.floor(Math.random() * alphabet.length);
      //console.log(randomIndex);
      var randomLetter = alphabet[randomIndex];
      randomLetters.push(randomLetter);
      randomLetters.push(randomLetter);
      // Creëer een nieuw alphabet zonder de gebruikte letter
      alphabet = alphabet.substring(0, randomIndex) + alphabet.substring(randomIndex + 1);
  }
  var array = Shuffle(randomLetters);
  console.log(array);
  return array;
}


  // Functie om de willekeurige letters toe te voegen aan de kaarten
  function Voeglettertoe() {
    const randomLetters = Genereerletter();
    console.log(randomLetters);

    kaartenAchterkant.forEach((kaartAchterkant, index) => {
      kaartAchterkant.innerHTML = randomLetters[index];
    
      
    });
  }
  function Startgame() {

    Maakklikactie();
    Voeglettertoe();
    document.getElementById('start').innerHTML = "Stop spel";
    document.getElementById('test').style.display = "none";
    document.getElementById('start').removeEventListener('click', function() {   
      Startgame();
  
    });
    document.getElementById('start').addEventListener('click', () => {
      
      location.reload(true);
  
    });
  }
  // Roep de functies aan bij het starten van het spel en verander de tekst en kleur van de knop
  document.getElementById('start').addEventListener('click', function() {
    
    Startgame();

  });

//Herlaad scherm na een gewonnen spel.
  document.getElementById('restart').addEventListener('click', () => {
      
    location.reload(true);

  });
  



