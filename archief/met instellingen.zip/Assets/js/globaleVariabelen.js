/* Door Marcel Bos ITC deeltijd leerjaar 3

globale variabelen*/

var kaarten = document.querySelectorAll('.Kaart');
var laadAnimatie = document.querySelector('.pop-up');
var kaartenAchterkant = document.querySelectorAll('.Kaart #achterkant');
var kaartenVoorkant = document.querySelectorAll('.Kaart #voorkant');
// later nog iets doen op basis van dit nummer met de grootte van het speelbord??

var aantalRijen = 6;
var aantalKolommen = 6;
var aantalKaarten = aantalKolommen * aantalRijen; 
//gevonden kaarten opslaan in lijst voor latere checks
var paren = [];
var vorigeLetter = '';
var leegmaken = 0; 

//Colorpickers
let colorPicker;

//Afbeeldingen api's
const willekeurigUrl = 'https://picsum.photos/80';
const kattenUrl = 'https://api.thecatapi.com/v1/images/search';
// katten url heeft api nodig..  'x-api-key'
const apiKattenKey = 'live_ghtZbkoeVo0EharQHJGHxP2zcDAEToRmgoRJ2szZYszSHdlhfN3GAggjlzFbh1tN';